title: 记一次iOS13 SceneDelegate的适配问题
date: '2019-11-18 17:20:15'
updated: '2019-11-18 17:48:41'
tags: [iOS]
permalink: /articles/2019/11/18/1574068815337.html
---
![](https://img.hacpai.com/bing/20180915.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

如果用Xcode11新建项目，会新增SceneDelegate文件，原来的AppDelegate里的方法也会发生改变，而原先的window属性在AppDelegate里已经找不到了，出现在了SceneDelegate里，可见window的管理已经由AppDelegate转交给了SceneDelegate。新增的这些特性都是iOS13特有的，所以iOS13以下是不支持这些特性的。
最近用Xcode11新创建了一个项目，不需要支持scene，把scene相关的方法都标注了@available(iOS 13.0, *), 在AppDelegate里面添加了window属性，和以前一样用纯代码创建window：
```
func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {

 // Override point for customization after application launch.

 window = UIWindow(frame: UIScreen.main.bounds)

 window?.rootViewController = TabBarController()

 window?.makeKeyAndVisible()

 return true

 }
```
选择iOS13的模拟器，cmd+r......咦？我的tabbar怎么不见了？等等，仔细回味一下刚刚这句话：“而原先的window属性在AppDelegate里已经找不到了，出现在了SceneDelegate里，可见window的管理已经由AppDelegate转交给了SceneDelegate”。我好像发现了什么.....
对的，在用Xcode11创建的项目里，iOS13的window已经不能在AppDelegate里创建了，应该在SceneDelegate里创建，正确的姿势如下：
```
 @available(iOS  13.0, *)

 func scene(_ scene: UIScene, willConnectTo session: UISceneSession, options connectionOptions: UIScene.ConnectionOptions) {

 // Use this method to optionally configure and attach the UIWindow `window` to the provided UIWindowScene `scene`.

 // If using a storyboard, the `window` property will automatically be initialized and attached to the scene.

 // This delegate does not imply the connecting scene or session are new (see `application:configurationForConnectingSceneSession` instead).

 guard let windowScene = (scene as? UIWindowScene) else { return }

 window = UIWindow(windowScene: windowScene)

 window?.rootViewController = TabBarController()

 window?.makeKeyAndVisible()

 }
```
选择iOS13的模拟器，cmd+r，完美！

当然，如果应用不用支持scene，直接把有关scene的方法都删掉，把SceneDelegate文件删掉，把info.plist里的Application Scene Manifest这个key删掉，然后和以前一样在AppDelegate里创建window，选择iOS13的模拟器，cmd+r，完美！
